# Twitter-Sentiment-Analysis-using-Python
Sentiment Analysis on Twitter Data

    -- Extracted data from twitter API
    -- Read the trending tweets
    -- Downloaded tweets for analysis
    -- Normalized the tweets from JSON to dataframe
    -- Counted and plotted nouns in the tweet
    -- Performed a sentiment analysis on the tweets
    -- Plotted the sentiment based on polarity
